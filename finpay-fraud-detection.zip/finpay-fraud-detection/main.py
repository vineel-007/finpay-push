"""
main.py
-------
Orchestrates the full FinPay Fraud Detection pipeline:
  1. Setup SQLite database with synthetic data
  2. Run SQL-based fraud queries
  3. Run NumPy statistical anomaly detection
"""

import sqlite3
import pandas as pd

from db_setup       import setup_database
from fraud_analysis import (
    load_transactions,
    print_summary_stats,
    run_zscore_analysis,
    run_iqr_analysis,
    category_risk_scores,
)

DB_PATH     = "finpay_transactions.db"
SQL_FILE    = "sql/queries.sql"


def run_sql_queries(conn: sqlite3.Connection):
    print("\n" + "=" * 55)
    print("  SQL — Fraud Detection Queries")
    print("=" * 55)

    queries = {
        "Overall Fraud Summary": """
            SELECT COUNT(*) AS total_transactions,
                   SUM(is_fraud) AS fraud_count,
                   ROUND(AVG(is_fraud)*100,2) AS fraud_rate_pct,
                   ROUND(SUM(CASE WHEN is_fraud=1 THEN amount END),2) AS total_fraud_amount
            FROM transactions
        """,
        "Fraud Rate by Merchant Category": """
            SELECT merchant_category,
                   COUNT(*) AS total_txns,
                   SUM(is_fraud) AS fraud_txns,
                   ROUND(AVG(is_fraud)*100,2) AS fraud_rate_pct
            FROM transactions
            GROUP BY merchant_category
            ORDER BY fraud_rate_pct DESC
        """,
        "Fraud Rate by Payment Mode": """
            SELECT payment_mode,
                   COUNT(*) AS total_txns,
                   SUM(is_fraud) AS fraud_txns,
                   ROUND(AVG(is_fraud)*100,2) AS fraud_rate_pct
            FROM transactions
            GROUP BY payment_mode
            ORDER BY fraud_rate_pct DESC
        """,
        "Top 5 Customers by Fraud Count": """
            SELECT customer_id,
                   SUM(is_fraud) AS fraud_txns,
                   ROUND(SUM(CASE WHEN is_fraud=1 THEN amount ELSE 0 END),2) AS fraud_amount
            FROM transactions
            GROUP BY customer_id
            HAVING fraud_txns > 0
            ORDER BY fraud_txns DESC
            LIMIT 5
        """,
        "Midnight-Window Fraud (00:00–02:59)": """
            SELECT COUNT(*) AS midnight_fraud_count,
                   ROUND(SUM(amount),2) AS total_amount
            FROM transactions
            WHERE CAST(STRFTIME('%H', timestamp) AS INTEGER) BETWEEN 0 AND 2
              AND is_fraud = 1
        """,
        "Fraud Flags by Type": """
            SELECT flag_type, COUNT(*) AS count
            FROM fraud_flags
            GROUP BY flag_type
            ORDER BY count DESC
        """,
    }

    for title, sql in queries.items():
        print(f"\n▶ {title}")
        result = pd.read_sql(sql, conn)
        print(result.to_string(index=False))


def main():
    print("🚀 FinPay Bank — Fraud Detection Analysis Pipeline")
    print("   Digital Payments Intelligence Platform (DPIP)")
    print("   " + "─" * 50)

    # Step 1: Build DB
    conn = setup_database()

    # Step 2: SQL queries
    run_sql_queries(conn)

    # Step 3: NumPy analysis
    df = load_transactions(conn)
    conn.close()

    print_summary_stats(df)
    run_zscore_analysis(df, threshold=3.0)
    run_iqr_analysis(df, k=1.5)
    category_risk_scores(df)

    print("\n✅ Pipeline complete. Database saved to finpay_transactions.db")


if __name__ == "__main__":
    main()
