-- ============================================================
-- FinPay Bank — Fraud Detection SQL Queries
-- Platform: Digital Payments Intelligence Platform (DPIP)
-- Author:   Fraud Analytics Team
-- ============================================================


-- ─────────────────────────────────────────────────────────────
-- Q1: Overall fraud summary
-- ─────────────────────────────────────────────────────────────
SELECT
    COUNT(*)                                        AS total_transactions,
    SUM(is_fraud)                                   AS fraud_count,
    ROUND(AVG(is_fraud) * 100, 2)                   AS fraud_rate_pct,
    ROUND(SUM(CASE WHEN is_fraud = 1 THEN amount END), 2) AS total_fraud_amount
FROM transactions;


-- ─────────────────────────────────────────────────────────────
-- Q2: High-value suspicious transactions (amount > ₹75,000)
-- ─────────────────────────────────────────────────────────────
SELECT
    transaction_id,
    customer_id,
    merchant_category,
    amount,
    payment_mode,
    timestamp,
    fraud_reason
FROM transactions
WHERE amount > 75000
  AND is_fraud = 1
ORDER BY amount DESC
LIMIT 20;


-- ─────────────────────────────────────────────────────────────
-- Q3: Fraud rate by merchant category
-- ─────────────────────────────────────────────────────────────
SELECT
    merchant_category,
    COUNT(*)                            AS total_txns,
    SUM(is_fraud)                       AS fraud_txns,
    ROUND(AVG(is_fraud) * 100, 2)       AS fraud_rate_pct,
    ROUND(SUM(CASE WHEN is_fraud = 1 THEN amount ELSE 0 END), 2) AS fraud_exposure_inr
FROM transactions
GROUP BY merchant_category
ORDER BY fraud_rate_pct DESC;


-- ─────────────────────────────────────────────────────────────
-- Q4: Fraud rate by payment mode
-- ─────────────────────────────────────────────────────────────
SELECT
    payment_mode,
    COUNT(*)                            AS total_txns,
    SUM(is_fraud)                       AS fraud_txns,
    ROUND(AVG(is_fraud) * 100, 2)       AS fraud_rate_pct
FROM transactions
GROUP BY payment_mode
ORDER BY fraud_rate_pct DESC;


-- ─────────────────────────────────────────────────────────────
-- Q5: Top 10 customers by fraud transaction count
-- ─────────────────────────────────────────────────────────────
SELECT
    customer_id,
    COUNT(*)                                    AS total_txns,
    SUM(is_fraud)                               AS fraud_txns,
    ROUND(SUM(CASE WHEN is_fraud = 1 THEN amount ELSE 0 END), 2) AS fraud_amount_inr,
    ROUND(AVG(is_fraud) * 100, 2)               AS fraud_rate_pct
FROM transactions
GROUP BY customer_id
HAVING fraud_txns > 0
ORDER BY fraud_txns DESC
LIMIT 10;


-- ─────────────────────────────────────────────────────────────
-- Q6: Midnight-window fraud (00:00 – 02:59)
-- ─────────────────────────────────────────────────────────────
SELECT
    transaction_id,
    customer_id,
    amount,
    payment_mode,
    timestamp,
    fraud_reason
FROM transactions
WHERE CAST(STRFTIME('%H', timestamp) AS INTEGER) BETWEEN 0 AND 2
  AND is_fraud = 1
ORDER BY timestamp;


-- ─────────────────────────────────────────────────────────────
-- Q7: Velocity check — customers with 3+ transactions in 1 hour
--     (proxy for card-testing / account takeover)
-- ─────────────────────────────────────────────────────────────
SELECT
    a.customer_id,
    COUNT(DISTINCT b.transaction_id) AS txns_in_window,
    MIN(b.amount)   AS min_amount,
    MAX(b.amount)   AS max_amount,
    MIN(b.timestamp) AS window_start,
    MAX(b.timestamp) AS window_end
FROM transactions a
JOIN transactions b
  ON  a.customer_id = b.customer_id
  AND b.timestamp BETWEEN a.timestamp
                      AND DATETIME(a.timestamp, '+1 hour')
GROUP BY a.customer_id, a.transaction_id
HAVING txns_in_window >= 3
ORDER BY txns_in_window DESC
LIMIT 10;


-- ─────────────────────────────────────────────────────────────
-- Q8: Merchants with highest fraud exposure
-- ─────────────────────────────────────────────────────────────
SELECT
    merchant_id,
    merchant_category,
    COUNT(*)                                                         AS total_txns,
    SUM(is_fraud)                                                    AS fraud_txns,
    ROUND(SUM(CASE WHEN is_fraud=1 THEN amount ELSE 0 END), 2)       AS fraud_exposure_inr,
    ROUND(AVG(is_fraud) * 100, 2)                                    AS fraud_rate_pct
FROM transactions
GROUP BY merchant_id
HAVING fraud_txns > 0
ORDER BY fraud_exposure_inr DESC
LIMIT 15;


-- ─────────────────────────────────────────────────────────────
-- Q9: Monthly fraud trend
-- ─────────────────────────────────────────────────────────────
SELECT
    STRFTIME('%Y-%m', timestamp)            AS month,
    COUNT(*)                                AS total_txns,
    SUM(is_fraud)                           AS fraud_txns,
    ROUND(AVG(is_fraud) * 100, 2)           AS fraud_rate_pct,
    ROUND(SUM(CASE WHEN is_fraud=1 THEN amount ELSE 0 END), 2) AS fraud_amount_inr
FROM transactions
GROUP BY month
ORDER BY month;


-- ─────────────────────────────────────────────────────────────
-- Q10: Fraud flags summary by flag type
-- ─────────────────────────────────────────────────────────────
SELECT
    flag_type,
    COUNT(*)                    AS flagged_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM fraud_flags), 2) AS pct_of_total
FROM fraud_flags
GROUP BY flag_type
ORDER BY flagged_count DESC;
