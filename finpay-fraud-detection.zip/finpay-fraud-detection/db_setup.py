"""
db_setup.py
-----------
Creates the SQLite database, defines schema, and loads generated transaction data.
"""

import sqlite3
import pandas as pd
from generate_data import generate_transactions

DB_PATH = "finpay_transactions.db"


SCHEMA = """
-- Drop if re-running
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS fraud_flags;

-- Core transactions table
CREATE TABLE transactions (
    transaction_id      TEXT PRIMARY KEY,
    customer_id         INTEGER NOT NULL,
    merchant_id         INTEGER NOT NULL,
    merchant_category   TEXT NOT NULL,
    amount              REAL NOT NULL,
    payment_mode        TEXT NOT NULL,
    timestamp           TEXT NOT NULL,
    is_fraud            INTEGER NOT NULL DEFAULT 0,  -- 0 = legit, 1 = fraud
    fraud_reason        TEXT
);

-- Fraud flags table (simulates downstream alert system)
CREATE TABLE fraud_flags (
    flag_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id  TEXT NOT NULL,
    flag_type       TEXT NOT NULL,
    flagged_at      TEXT NOT NULL,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

-- Indexes for query performance
CREATE INDEX idx_customer    ON transactions(customer_id);
CREATE INDEX idx_merchant    ON transactions(merchant_id);
CREATE INDEX idx_timestamp   ON transactions(timestamp);
CREATE INDEX idx_is_fraud    ON transactions(is_fraud);
CREATE INDEX idx_amount      ON transactions(amount);
"""


def setup_database() -> sqlite3.Connection:
    print("📦 Generating synthetic transaction data...")
    df = generate_transactions()

    print(f"🗄️  Setting up SQLite database at: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)

    df.to_sql("transactions", conn, if_exists="append", index=False)

    # Populate fraud_flags from known fraud rows
    fraud_df = df[df["is_fraud"] == 1][["transaction_id", "fraud_reason", "timestamp"]].copy()
    fraud_df.rename(columns={"fraud_reason": "flag_type", "timestamp": "flagged_at"}, inplace=True)
    fraud_df.to_sql("fraud_flags", conn, if_exists="append", index=False)

    conn.commit()

    total = pd.read_sql("SELECT COUNT(*) AS cnt FROM transactions", conn).iloc[0, 0]
    fraud = pd.read_sql("SELECT COUNT(*) AS cnt FROM transactions WHERE is_fraud=1", conn).iloc[0, 0]
    print(f"✅ Loaded {total:,} transactions | Fraud rows: {fraud:,}")
    return conn


if __name__ == "__main__":
    conn = setup_database()
    conn.close()
    print("Database ready.")
