"""
fraud_analysis.py
-----------------
Statistical anomaly detection using NumPy.
Techniques: Z-Score, IQR (Interquartile Range), and transaction velocity scoring.
"""

import numpy as np
import pandas as pd
import sqlite3

DB_PATH = "finpay_transactions.db"


# ── 1. Load Data ──────────────────────────────────────────────────────────────

def load_transactions(conn: sqlite3.Connection) -> pd.DataFrame:
    return pd.read_sql("SELECT * FROM transactions", conn,
                       parse_dates=["timestamp"])


# ── 2. Z-Score Anomaly Detection ──────────────────────────────────────────────

def zscore_anomalies(amounts: np.ndarray, threshold: float = 3.0) -> np.ndarray:
    """
    Flag transactions where amount deviates > `threshold` standard deviations
    from the mean. Classic parametric outlier detection.
    """
    mean   = np.mean(amounts)
    std    = np.std(amounts)
    scores = np.abs((amounts - mean) / std)
    return scores


def run_zscore_analysis(df: pd.DataFrame, threshold: float = 3.0) -> pd.DataFrame:
    amounts = df["amount"].to_numpy(dtype=float)
    df = df.copy()
    df["zscore"] = zscore_anomalies(amounts, threshold)
    df["zscore_flag"] = (df["zscore"] > threshold).astype(int)

    flagged = df[df["zscore_flag"] == 1]
    print(f"\n📊 Z-Score Analysis (threshold={threshold}σ)")
    print(f"   Flagged : {len(flagged):,} transactions")
    print(f"   Of which are actual fraud : "
          f"{flagged['is_fraud'].sum():,} ({flagged['is_fraud'].mean()*100:.1f}%)")
    print(f"   Avg amount (flagged) : ₹{flagged['amount'].mean():,.2f}")
    return df


# ── 3. IQR Anomaly Detection ──────────────────────────────────────────────────

def iqr_anomalies(amounts: np.ndarray, k: float = 1.5) -> tuple[float, float]:
    """
    Returns (lower_bound, upper_bound) using IQR fencing.
    Non-parametric — more robust against skewed distributions.
    """
    q1 = np.percentile(amounts, 25)
    q3 = np.percentile(amounts, 75)
    iqr = q3 - q1
    lower = q1 - k * iqr
    upper = q3 + k * iqr
    return lower, upper


def run_iqr_analysis(df: pd.DataFrame, k: float = 1.5) -> pd.DataFrame:
    amounts = df["amount"].to_numpy(dtype=float)
    lower, upper = iqr_anomalies(amounts, k)

    df = df.copy()
    df["iqr_flag"] = ((df["amount"] < lower) | (df["amount"] > upper)).astype(int)

    flagged = df[df["iqr_flag"] == 1]
    print(f"\n📊 IQR Analysis (k={k})")
    print(f"   Bounds  : ₹{lower:,.2f} — ₹{upper:,.2f}")
    print(f"   Flagged : {len(flagged):,} transactions")
    print(f"   Of which are actual fraud : "
          f"{flagged['is_fraud'].sum():,} ({flagged['is_fraud'].mean()*100:.1f}%)")
    return df


# ── 4. Category-Level Risk Scoring ────────────────────────────────────────────

def category_risk_scores(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute per-category fraud rate and assign a normalised risk score (0–1)
    using NumPy operations.
    """
    categories = df["merchant_category"].unique()
    records = []
    for cat in categories:
        mask   = df["merchant_category"] == cat
        subset = df[mask]
        fraud_rate = np.mean(subset["is_fraud"].to_numpy())
        avg_amount = np.mean(subset["amount"].to_numpy())
        records.append({"merchant_category": cat,
                         "fraud_rate": fraud_rate,
                         "avg_amount": avg_amount,
                         "txn_count": len(subset)})

    cat_df = pd.DataFrame(records)
    # Normalise fraud_rate to [0, 1] risk score
    min_fr, max_fr = cat_df["fraud_rate"].min(), cat_df["fraud_rate"].max()
    cat_df["risk_score"] = np.round(
        (cat_df["fraud_rate"] - min_fr) / (max_fr - min_fr + 1e-9), 4
    )
    cat_df = cat_df.sort_values("risk_score", ascending=False)
    print(f"\n📊 Merchant Category Risk Scores")
    print(cat_df.to_string(index=False))
    return cat_df


# ── 5. Velocity Score ─────────────────────────────────────────────────────────

def velocity_scores(df: pd.DataFrame, window_minutes: int = 60) -> pd.DataFrame:
    """
    For each transaction, count how many other transactions the same customer
    made within the previous `window_minutes`. High velocity → suspicious.
    Uses NumPy for timestamp arithmetic.
    """
    df = df.copy().sort_values("timestamp")
    df["velocity_count"] = 0

    ts_array     = df["timestamp"].to_numpy(dtype="datetime64[s]")
    cust_array   = df["customer_id"].to_numpy()
    window_delta = np.timedelta64(window_minutes, "m")

    counts = np.zeros(len(df), dtype=int)
    for i in range(len(df)):
        window_mask = (
            (cust_array == cust_array[i]) &
            (ts_array   >= ts_array[i] - window_delta) &
            (ts_array   <  ts_array[i])
        )
        counts[i] = window_mask.sum()

    df["velocity_count"] = counts
    df["velocity_flag"]  = (counts >= 3).astype(int)

    flagged = df[df["velocity_flag"] == 1]
    print(f"\n📊 Velocity Analysis (window={window_minutes}min, threshold=3 txns)")
    print(f"   Flagged : {len(flagged):,} transactions")
    print(f"   Actual fraud in flagged : {flagged['is_fraud'].sum():,}")
    return df


# ── 6. Summary Statistics ─────────────────────────────────────────────────────

def print_summary_stats(df: pd.DataFrame):
    amounts = df["amount"].to_numpy(dtype=float)
    fraud_amounts = df[df["is_fraud"] == 1]["amount"].to_numpy(dtype=float)

    print("\n" + "=" * 55)
    print("  FinPay Bank — Transaction Statistical Summary")
    print("=" * 55)
    print(f"  Total transactions : {len(df):,}")
    print(f"  Fraud transactions : {df['is_fraud'].sum():,} "
          f"({df['is_fraud'].mean()*100:.2f}%)")
    print(f"\n  Amount (all txns)")
    print(f"    Mean    : ₹{np.mean(amounts):>12,.2f}")
    print(f"    Median  : ₹{np.median(amounts):>12,.2f}")
    print(f"    Std Dev : ₹{np.std(amounts):>12,.2f}")
    print(f"    P95     : ₹{np.percentile(amounts, 95):>12,.2f}")
    print(f"    P99     : ₹{np.percentile(amounts, 99):>12,.2f}")
    print(f"    Max     : ₹{np.max(amounts):>12,.2f}")
    print(f"\n  Amount (fraud txns only)")
    print(f"    Mean    : ₹{np.mean(fraud_amounts):>12,.2f}")
    print(f"    Median  : ₹{np.median(fraud_amounts):>12,.2f}")
    print(f"    Max     : ₹{np.max(fraud_amounts):>12,.2f}")
    print("=" * 55)


# ── Run standalone ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    conn = sqlite3.connect(DB_PATH)
    df   = load_transactions(conn)
    conn.close()

    print_summary_stats(df)
    df = run_zscore_analysis(df)
    df = run_iqr_analysis(df)
    category_risk_scores(df)
