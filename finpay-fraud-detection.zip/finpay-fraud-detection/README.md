# 🏦 FinPay Fraud Detection Analysis

> SQL + NumPy based fraud detection pipeline built on synthetic FinPay Bank transaction data.  
> Simulates a real-world Digital Payments Intelligence Platform (DPIP) use case.

---

## 📌 Overview

This project demonstrates end-to-end fraud detection analytics across 10,000 synthetic payment transactions, covering:

- **SQL-based querying** — fraud pattern analysis by category, payment mode, customer, and time window
- **NumPy statistical detection** — Z-Score and IQR anomaly detection on transaction amounts
- **Fraud signal simulation** — four embedded fraud patterns: high-amount, velocity, odd-hour, and high-risk merchant

Built as a portfolio artifact reflecting practical work in fintech BA/analytics roles.

---

## 🗂️ Project Structure

```
finpay-fraud-detection/
│
├── generate_data.py       # Synthetic transaction data generation (NumPy)
├── db_setup.py            # SQLite schema creation + data loading
├── fraud_analysis.py      # Statistical anomaly detection (Z-Score, IQR)
├── main.py                # Full pipeline orchestrator
│
├── sql/
│   └── queries.sql        # Standalone SQL fraud detection queries
│
├── requirements.txt
├── .gitignore
└── README.md
```

---

## ⚙️ Setup & Run

```bash
# Clone the repo
git clone https://github.com/<your-username>/finpay-fraud-detection.git
cd finpay-fraud-detection

# Install dependencies
pip install -r requirements.txt

# Run the full pipeline
python main.py
```

The pipeline will:
1. Generate 10,000 synthetic transactions with a ~4% fraud rate
2. Load them into a local SQLite database (`finpay_transactions.db`)
3. Run SQL fraud analysis queries
4. Run NumPy-based statistical anomaly detection

---

## 🔍 Fraud Patterns Simulated

| Pattern | Description |
|--------|-------------|
| **High Amount** | Transactions above ₹80,000 — outlier detection via Z-Score & IQR |
| **Velocity** | Multiple transactions by the same customer within a 1-hour window |
| **Odd Hour** | Transactions between 00:00–02:59 — behavioural anomaly |
| **High-Risk Merchant** | Crypto Exchange and Gaming category transactions |

---

## 📊 SQL Queries Included

| Query | Purpose |
|-------|---------|
| Overall Fraud Summary | Total counts, fraud rate, exposure in INR |
| Fraud by Merchant Category | Category-level fraud rate ranking |
| Fraud by Payment Mode | UPI / IMPS / NEFT / RTGS / Card breakdown |
| Top Customers by Fraud Count | Risk-ranked customer list |
| Midnight-Window Fraud | Odd-hour transaction isolation |
| Velocity Check | 3+ transactions within 1-hour window |
| Merchant Fraud Exposure | Merchant-level risk ranking |
| Monthly Fraud Trend | Time-series fraud rate by month |
| Fraud Flags Summary | Breakdown by alert type |

---

## 🧮 NumPy Techniques Used

| Technique | Application |
|-----------|-------------|
| `np.mean`, `np.std` | Z-Score calculation for amount outliers |
| `np.percentile` | IQR fencing (Q1, Q3) for robust outlier detection |
| `np.timedelta64` | Velocity window computation over timestamps |
| Array normalisation | Merchant category risk scoring (0–1 scale) |
| `np.lognormal` | Realistic transaction amount simulation |

---

## 🧱 Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Python 3.11+ |
| Database | SQLite (via `sqlite3`) |
| Data manipulation | Pandas |
| Statistical analysis | NumPy |
| Storage format | `.db` (local), `.sql` (queries) |

---

## 📁 Data Model

```sql
transactions (
    transaction_id      TEXT PRIMARY KEY,
    customer_id         INTEGER,
    merchant_id         INTEGER,
    merchant_category   TEXT,
    amount              REAL,
    payment_mode        TEXT,    -- UPI | IMPS | NEFT | RTGS | Card
    timestamp           TEXT,
    is_fraud            INTEGER, -- 0 = legit, 1 = fraud
    fraud_reason        TEXT
)

fraud_flags (
    flag_id         INTEGER PRIMARY KEY,
    transaction_id  TEXT,
    flag_type       TEXT,
    flagged_at      TEXT
)
```

---

## 👤 Author

**Venkata Vineel Sai Mugada**  
Technical Business Analyst | Fintech & Digital Payments  
[LinkedIn](https://linkedin.com/in/) · [GitHub](https://github.com/)

---

## 📄 License

MIT License — free to use, adapt, and build on.
