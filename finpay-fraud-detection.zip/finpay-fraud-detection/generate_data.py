"""
generate_data.py
----------------
Generates synthetic FinPay Bank transaction data using NumPy.
Simulates realistic payment patterns including embedded fraud signals.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(42)

# ── Config ────────────────────────────────────────────────────────────────────
N_TRANSACTIONS   = 10_000
FRAUD_RATE       = 0.04          # 4% fraud
N_CUSTOMERS      = 500
N_MERCHANTS      = 150

MERCHANT_CATEGORIES = [
    "Retail", "Food & Dining", "Travel", "Electronics",
    "Utilities", "Healthcare", "Gaming", "Crypto Exchange"
]

# Crypto Exchange and Gaming are higher-risk categories
HIGH_RISK_CATS = {"Crypto Exchange", "Gaming"}

PAYMENT_MODES = ["UPI", "IMPS", "NEFT", "RTGS", "Card"]

# ── Helpers ───────────────────────────────────────────────────────────────────
def random_timestamps(n: int) -> list[str]:
    base = datetime(2024, 1, 1)
    offsets = np.random.randint(0, 365 * 24 * 3600, size=n)
    return [(base + timedelta(seconds=int(o))).strftime("%Y-%m-%d %H:%M:%S")
            for o in offsets]


def generate_transactions() -> pd.DataFrame:
    n_legit = int(N_TRANSACTIONS * (1 - FRAUD_RATE))
    n_fraud = N_TRANSACTIONS - n_legit

    # ── Legitimate transactions ───────────────────────────────────────────────
    legit_amounts = np.random.lognormal(mean=7.5, sigma=1.2, size=n_legit)
    legit_amounts = np.clip(legit_amounts, 10, 50_000)

    legit = {
        "transaction_id"   : [f"TXN{str(i).zfill(7)}" for i in range(n_legit)],
        "customer_id"      : np.random.randint(1, N_CUSTOMERS + 1, n_legit),
        "merchant_id"      : np.random.randint(1, N_MERCHANTS + 1, n_legit),
        "merchant_category": np.random.choice(MERCHANT_CATEGORIES, n_legit,
                                               p=[0.25,0.20,0.15,0.12,0.10,0.08,0.06,0.04]),
        "amount"           : np.round(legit_amounts, 2),
        "payment_mode"     : np.random.choice(PAYMENT_MODES, n_legit,
                                               p=[0.40,0.25,0.15,0.05,0.15]),
        "timestamp"        : random_timestamps(n_legit),
        "is_fraud"         : np.zeros(n_legit, dtype=int),
        "fraud_reason"     : [""] * n_legit,
    }

    # ── Fraudulent transactions ───────────────────────────────────────────────
    fraud_patterns = np.random.choice(
        ["high_amount", "velocity", "odd_hour", "high_risk_merchant"],
        size=n_fraud,
        p=[0.30, 0.25, 0.25, 0.20]
    )

    fraud_amounts = []
    fraud_timestamps = []
    fraud_categories = []
    fraud_reasons = []

    for pattern in fraud_patterns:
        if pattern == "high_amount":
            fraud_amounts.append(round(np.random.uniform(80_000, 500_000), 2))
            fraud_timestamps.append(random_timestamps(1)[0])
            fraud_categories.append(np.random.choice(MERCHANT_CATEGORIES))
            fraud_reasons.append("Unusually high transaction amount")

        elif pattern == "velocity":
            fraud_amounts.append(round(np.random.uniform(100, 5_000), 2))
            fraud_timestamps.append(random_timestamps(1)[0])
            fraud_categories.append(np.random.choice(MERCHANT_CATEGORIES))
            fraud_reasons.append("High velocity — multiple txns in short window")

        elif pattern == "odd_hour":
            base = datetime(2024, 1, 1)
            midnight_offset = np.random.randint(0, 365) * 86400 + \
                              np.random.randint(0, 3) * 3600    # 00:00–02:59
            ts = (base + timedelta(seconds=int(midnight_offset))).strftime("%Y-%m-%d %H:%M:%S")
            fraud_amounts.append(round(np.random.uniform(5_000, 50_000), 2))
            fraud_timestamps.append(ts)
            fraud_categories.append(np.random.choice(MERCHANT_CATEGORIES))
            fraud_reasons.append("Transaction at unusual hour (midnight window)")

        else:  # high_risk_merchant
            fraud_amounts.append(round(np.random.uniform(500, 30_000), 2))
            fraud_timestamps.append(random_timestamps(1)[0])
            fraud_categories.append(np.random.choice(list(HIGH_RISK_CATS)))
            fraud_reasons.append("High-risk merchant category")

    fraud = {
        "transaction_id"   : [f"TXN{str(n_legit + i).zfill(7)}" for i in range(n_fraud)],
        "customer_id"      : np.random.randint(1, N_CUSTOMERS + 1, n_fraud),
        "merchant_id"      : np.random.randint(1, N_MERCHANTS + 1, n_fraud),
        "merchant_category": fraud_categories,
        "amount"           : fraud_amounts,
        "payment_mode"     : np.random.choice(PAYMENT_MODES, n_fraud),
        "timestamp"        : fraud_timestamps,
        "is_fraud"         : np.ones(n_fraud, dtype=int),
        "fraud_reason"     : fraud_reasons,
    }

    df = pd.concat([pd.DataFrame(legit), pd.DataFrame(fraud)], ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = generate_transactions()
    print(f"Generated {len(df):,} transactions | Fraud: {df['is_fraud'].sum():,} "
          f"({df['is_fraud'].mean()*100:.1f}%)")
    print(df.head())
